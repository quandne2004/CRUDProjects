package CRUDProjects.CRUDProjects;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudProjectsApplicationTests {

	@Test
	void contextLoads() {
	}

}
