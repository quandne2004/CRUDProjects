package CRUDProjects.CRUDProjects.service;


import CRUDProjects.CRUDProjects.entity.Car;
import CRUDProjects.CRUDProjects.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CarServiceImpl implements CarService{


    private CarRepository carRepository;

    @Autowired
    public CarServiceImpl(CarRepository carRepository){
        this.carRepository = carRepository;
    }




    public List<Car> getAllCar(){
        return carRepository.findAll();
    }

    public Car findCarById(Long carId) throws Exception {
        Optional<Car> car = carRepository.findById(carId);
        Car thCar = null;
        if (car.isPresent()){
            thCar = car.get();
        }else {
         throw new Exception("not found" + carId);
        }
        return thCar;
    }

    public void save(Car car){
        carRepository.save(car);
    }

    public void  deleteCarById(Long carId){
        carRepository.deleteById(carId);
    }



}
