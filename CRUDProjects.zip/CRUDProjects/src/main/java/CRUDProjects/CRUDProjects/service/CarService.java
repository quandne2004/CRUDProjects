package CRUDProjects.CRUDProjects.service;

import CRUDProjects.CRUDProjects.entity.Car;

import java.util.List;

public interface CarService {

    List<Car> getAllCar();
    Car findCarById(Long carId) throws Exception;
    void save(Car car);
    void  deleteCarById(Long carId);
}
