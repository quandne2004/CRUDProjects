package CRUDProjects.CRUDProjects.controller;


import CRUDProjects.CRUDProjects.entity.Car;
import CRUDProjects.CRUDProjects.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("cars")
public class CarController {

    @Autowired
    private CarService carService;

    @GetMapping("/list")
    public String listCars(Model model) {
        model.addAttribute("cars", carService.getAllCar());
        return "car_list"; // Tên của template trong thư mục templates
    }

    @GetMapping("/showFormForAdd")
    public String showFormForAdd(Model model) {
        Car car = new Car();
        model.addAttribute("car",car );
        return "car_form"; // Tên của template trong thư mục templates
    }

    @GetMapping("/showFormForUpdate")
    public String showFormForUpdate(@RequestParam("employeeId") Long carId, Model model) throws Exception {
        Car car = carService.findCarById(carId);
        model.addAttribute("car", car);
        return "car_form"; // Tên của template trong thư mục templates
    }

    @PostMapping("/save")
    public String saveCar(@ModelAttribute("car") Car car) {
        carService.save(car);
        return "redirect:/cars/list";
    }

    @GetMapping("/delete")
    public String delete(@RequestParam("carId") Long id) {
        carService.deleteCarById(id);
        return "redirect:/cars/list";
    }
}
