package CRUDProjects.CRUDProjects;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudProjectsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudProjectsApplication.class, args);
	}

}
